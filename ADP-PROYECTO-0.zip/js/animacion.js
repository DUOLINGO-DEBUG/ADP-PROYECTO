window.onload = function(){
    
    setTimeout(function() {
        $('#carga').fadeOut();
        // Coloca aquí el código que deseas ejecutar después de la pausa de 5 segundos
    }, 3000);
}

